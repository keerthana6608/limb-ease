export const colors = {
  bg: '#FFFFFF',
  card: '#FFFFFF',
  border: '#E6E6E6',
  borderStrong: '#CFCFCF',
  text: '#111111',
  muted: '#6B6B6B',
  faint: '#9A9A9A',
  track: '#E4E4E4',
  black: '#000000',
  green: '#1E9E5A',
  greenSoft: '#E6F6EC',
  red: '#E5322D',
  redSoft: '#FDECEB',
  amber: '#E39B12',
  amberSoft: '#FFF4DC',
  blue: '#3478F6',
  orange: '#F26B2A',
};

export const radius = { card: 14, button: 12, pill: 999 };

export const shadow = {
  shadowColor: '#000',
  shadowOpacity: 0.06,
  shadowRadius: 6,
  shadowOffset: { width: 0, height: 2 },
  elevation: 2,
};

export const SERIES_COLORS = {
  pressure: colors.blue,
  flex: colors.green,
  temp: colors.orange,
};
