import { SIM_INTERVAL_MS } from '../config/demo';

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const rand = (a, b) => a + Math.random() * (b - a);

/**
 * Generates smoothly changing fake readings inside configurable ranges.
 * `getRanges` is a function so range changes made in Profile apply immediately.
 */
export class SimulatedSensorSource {
  constructor({ getRanges, intervalMs = SIM_INTERVAL_MS }) {
    this.id = 'simulated';
    this.isSimulated = true;
    this.getRanges = getRanges;
    this.intervalMs = intervalMs;
    this.timer = null;
    this.t = 0;
    this.state = null;
  }

  _init() {
    const r = this.getRanges();
    // Start from a random point inside each range (so every session differs).
    this.state = {
      pressure: rand(r.pressure.min, r.pressure.max),
      temp: rand(r.temp.min, r.temp.max),
      flexPhase: rand(0, Math.PI * 2),
    };
  }

  next() {
    const r = this.getRanges();
    if (!this.state) this._init();
    const s = this.state;
    this.t += 1;

    // Pressure & temperature: bounded random walk.
    s.pressure = clamp(s.pressure + rand(-3, 3), r.pressure.min, r.pressure.max);
    s.temp = clamp(s.temp + rand(-0.25, 0.25), r.temp.min, r.temp.max);

    // Flex angle: slow sine (like gentle leg movement) plus noise.
    const mid = (r.flex.min + r.flex.max) / 2;
    const amp = (r.flex.max - r.flex.min) / 2;
    const flex = clamp(
      mid + amp * 0.8 * Math.sin(s.flexPhase + this.t / 6) + rand(-4, 4),
      r.flex.min,
      r.flex.max,
    );

    return {
      ts: Date.now(),
      pressure: Math.round(s.pressure * 10) / 10,
      flex: Math.round(flex),
      temp: Math.round(s.temp * 10) / 10,
    };
  }

  start(onReading) {
    if (this.timer) return;
    onReading(this.next());
    this.timer = setInterval(() => onReading(this.next()), this.intervalMs);
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
}
