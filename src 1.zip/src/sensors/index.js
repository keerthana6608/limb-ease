import { SimulatedSensorSource } from './SimulatedSensorSource';
import { BluetoothSensorSource } from './BluetoothSensorSource';

export { parseSensorPacket } from './SensorSource';

/**
 * The ONE place that decides where readings come from.
 * Switch `mode` to 'bluetooth' (once implemented) and the whole app uses hardware data.
 */
export function createSensorSource({ mode = 'simulated', getRanges }) {
  if (mode === 'bluetooth') return new BluetoothSensorSource();
  return new SimulatedSensorSource({ getRanges });
}
