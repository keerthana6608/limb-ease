/**
 * PLACEHOLDER for the future Arduino Uno + HC-05/HC-06 (or BLE) hardware module.
 * Intentionally NOT implemented: the project has no hardware yet.
 *
 * When you are ready, implement start() so that for every line received from the
 * Arduino you call:
 *
 *     const reading = parseSensorPacket(line);   // from ./SensorSource
 *     if (reading) onReading(reading);
 *
 * Suggested libraries (free): react-native-ble-plx (BLE modules such as HM-10) or
 * react-native-bluetooth-classic (HC-05/HC-06). Both need a custom dev build or an
 * APK - they do not run inside Expo Go.
 *
 * Suggested Arduino sketch output (every 200-1000 ms):
 *     Serial.println("P:" + String(kPa) + ",F:" + String(deg) + ",T:" + String(degC));
 */
export class BluetoothSensorSource {
  constructor() {
    this.id = 'bluetooth';
    this.isSimulated = false;
  }

  start(_onReading, onError) {
    if (onError) onError(new Error('Bluetooth hardware source is not implemented yet.'));
  }

  stop() {}
}
