/**
 * SENSOR SOURCE INTERFACE
 * -----------------------
 * The UI never talks to hardware directly. It only talks to a "sensor source"
 * object with this shape (duck-typed):
 *
 *   {
 *     id: string,                 // 'simulated' | 'bluetooth' | ...
 *     isSimulated: boolean,       // UI shows a "SIMULATED" badge when true
 *     start(onReading, onError),  // begin streaming
 *     stop(),                     // stop streaming
 *   }
 *
 * onReading receives a reading object:
 *   { ts: number (ms epoch), pressure: number (kPa), flex: number (deg), temp: number (degC) }
 *
 * To add real hardware later, create a new file (see BluetoothSensorSource.js),
 * implement this shape, and return it from createSensorSource() in index.js.
 * No screen needs to change.
 */

/**
 * Parses one line sent by the Arduino Uno, e.g.  "P:45.2,F:62,T:32.4\n"
 *   P = pressure sensor (kPa), F = flex sensor (degrees), T = temperature (°C)
 * Returns a reading object or null when the line is malformed.
 * (Already usable & unit-tested; the Bluetooth transport itself is not implemented yet.)
 */
export function parseSensorPacket(line, now = Date.now()) {
  if (typeof line !== 'string') return null;
  const out = {};
  for (const part of line.trim().split(',')) {
    const [k, v] = part.split(':');
    const num = parseFloat(v);
    if (!k || Number.isNaN(num)) return null;
    out[k.trim().toUpperCase()] = num;
  }
  if (!('P' in out) || !('F' in out) || !('T' in out)) return null;
  return { ts: now, pressure: out.P, flex: out.F, temp: out.T };
}
