// Pure calculation helpers. Everything the Reports / Pain Tracking screens show
// is computed here from the records the user actually saved.
import {
  addDays, addMonths, formatDate, monthLabel, round1, shortDay,
  startOfDay, startOfMonth, startOfWeek,
} from './format';

export function painLabel(level) {
  if (level == null) return 'No data';
  if (level === 0) return 'No Pain';
  if (level <= 3) return 'Mild Pain';
  if (level <= 6) return 'Moderate Pain';
  if (level <= 8) return 'Severe Pain';
  return 'Worst Pain';
}

export function painShort(level) {
  if (level == null) return '—';
  if (level === 0) return 'None';
  if (level <= 3) return 'Mild';
  if (level <= 6) return 'Moderate';
  if (level <= 8) return 'Severe';
  return 'Worst';
}

export function average(nums) {
  const v = nums.filter((n) => typeof n === 'number' && !Number.isNaN(n));
  if (!v.length) return null;
  return v.reduce((a, b) => a + b, 0) / v.length;
}

export function between(list, from, to, key = 'ts') {
  return list.filter((x) => x[key] >= from && x[key] < to);
}

// One point per day for the last `days` days (ending today). avg is null for
// days without any saved record, so the chart shows a gap rather than a made-up value.
export function dailyAverages(entries, now, days) {
  const today = startOfDay(now);
  const out = [];
  for (let i = days - 1; i >= 0; i--) {
    const from = addDays(today, -i);
    const to = addDays(from, 1);
    const dayEntries = between(entries, from, to);
    const avg = average(dayEntries.map((e) => e.level));
    out.push({
      ts: from,
      label: shortDay(from),
      avg: avg == null ? null : round1(avg),
      count: dayEntries.length,
    });
  }
  return out;
}

// Improvement = drop in average pain: last 7 days vs the 7 days before.
// Only reported when BOTH windows contain at least 2 saved records.
export function improvement(entries, now) {
  const today = startOfDay(now);
  const curFrom = addDays(today, -6);
  const curTo = addDays(today, 1);
  const prevFrom = addDays(today, -13);
  const cur = between(entries, curFrom, curTo).map((e) => e.level);
  const prev = between(entries, prevFrom, curFrom).map((e) => e.level);
  if (cur.length < 2 || prev.length < 2) {
    return { ok: false, reason: 'Needs at least 2 records in this week and last week' };
  }
  const a = average(cur);
  const b = average(prev);
  if (b === 0) {
    return { ok: false, reason: 'Last week average was 0, so a percentage is undefined' };
  }
  const pct = Math.round(((b - a) / b) * 100);
  return { ok: true, pct, better: pct > 0, same: pct === 0 };
}

// ---- Reports -------------------------------------------------------------
export function periodRange(filter, anchor) {
  if (filter === 'Daily') {
    const from = startOfDay(anchor);
    return { from, to: addDays(from, 1), label: formatDate(from), key: `daily:${from}` };
  }
  if (filter === 'Weekly') {
    const from = startOfWeek(anchor);
    const to = addDays(from, 7);
    return {
      from, to,
      label: `${shortDay(from)} – ${formatDate(addDays(to, -1))}`,
      key: `weekly:${from}`,
    };
  }
  const from = startOfMonth(anchor);
  return { from, to: addMonths(from, 1), label: monthLabel(from), key: `monthly:${from}` };
}

export function shiftAnchor(filter, anchor, dir) {
  if (filter === 'Daily') return addDays(anchor, dir);
  if (filter === 'Weekly') return addDays(anchor, 7 * dir);
  return addMonths(startOfMonth(anchor), dir);
}

// Relief compares the first and last pain record inside the period.
export function reliefFor(painInPeriod) {
  if (painInPeriod.length < 2) return { label: 'Not enough data', tone: 'muted' };
  const sorted = [...painInPeriod].sort((a, b) => a.ts - b.ts);
  const diff = sorted[0].level - sorted[sorted.length - 1].level;
  if (diff >= 2) return { label: 'Good', tone: 'good' };
  if (diff === 1) return { label: 'Slight', tone: 'good' };
  if (diff === 0) return { label: 'No change', tone: 'muted' };
  return { label: 'Pain increased', tone: 'bad' };
}

export function summarizePeriod(filter, anchor, painEntries, sessions) {
  const range = periodRange(filter, anchor);
  const pain = between(painEntries, range.from, range.to).sort((a, b) => a.ts - b.ts);
  const sess = between(sessions, range.from, range.to, 'startTs').sort((a, b) => a.startTs - b.startTs);
  const avg = average(pain.map((p) => p.level));
  return {
    range,
    pain,
    sessions: sess,
    avgPain: avg == null ? null : round1(avg),
    totalSec: sess.reduce((t, s) => t + (s.durationSec || 0), 0),
    sessionCount: sess.length,
    relief: reliefFor(pain),
  };
}
