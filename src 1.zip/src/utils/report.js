import { Platform } from 'react-native';
import { buildReportHtml } from './reportHtml';

// Creates a PDF file and opens the system share sheet (save to Files/Drive, send, print...).
export async function exportReportPdf(args) {
  const Print = require('expo-print');
  const html = buildReportHtml(args);
  if (Platform.OS === 'web') {
    await Print.printAsync({ html }); // opens the browser print dialog -> "Save as PDF"
    return { kind: 'web' };
  }
  const Sharing = require('expo-sharing');
  const { uri } = await Print.printToFileAsync({ html });
  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(uri, {
      mimeType: 'application/pdf',
      dialogTitle: 'Save or share your Limb Ease report',
      UTI: 'com.adobe.pdf',
    });
    return { kind: 'shared', uri };
  }
  return { kind: 'saved', uri };
}
