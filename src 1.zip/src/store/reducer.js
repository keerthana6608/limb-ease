// Pure state logic (no React Native imports) so it can be unit-tested anywhere.
import { DEFAULT_SENSOR_RANGES } from '../config/demo';
import { clamp, uid } from '../utils/format';

export const initialState = {
  hydrated: false,
  profile: {
    name: 'User',
    email: 'user@example.com',
    age: '',
    gender: '',
    heightCm: '',
    weightKg: '',
    kneeSide: 'Right',
    condition: '',
  },
  device: {
    name: 'LimbEase Knee Brace',
    model: 'LE-K1 (prototype)',
    firmware: '0.1.0-sim',
    mode: 'simulated', // 'simulated' | 'bluetooth' (bluetooth not implemented yet)
    connected: true,   // simulated connection state; not persisted
  },
  sensorRanges: DEFAULT_SENSOR_RANGES,
  therapySettings: { intensity: 5, pulseWidth: 200, frequency: 50, durationMin: 20 },
  reminders: { enabled: true, time: '09:00' },
  painEntries: [],   // { id, ts, level(0-10), note, sample? }
  sessions: [],      // { id, startTs, endTs, durationSec, plannedMin, intensity, pulseWidth, frequency, endedBy, sample? }
  reportNotes: {},   // { [periodKey]: string }
  therapy: {
    status: 'OFF',   // 'ON' | 'OFF'  (runtime only; never persisted)
    startedAt: null,
    plannedSec: 0,
    intensity: 5,
    pulseWidth: 200,
    frequency: 50,
    lastEnd: null,   // { reason, durationSec, at } of the most recent session
  },
};

export const PERSISTED_KEYS = [
  'profile', 'device', 'sensorRanges', 'therapySettings', 'reminders',
  'painEntries', 'sessions', 'reportNotes',
];

export function toPersisted(state) {
  const out = {};
  PERSISTED_KEYS.forEach((k) => { out[k] = state[k]; });
  out.device = { ...state.device, connected: undefined };
  return out;
}

function finishSession(state, reason, now) {
  const t = state.therapy;
  if (t.status !== 'ON') return state;
  const rawSec = Math.max(0, Math.round((now - t.startedAt) / 1000));
  const durationSec = Math.min(rawSec, t.plannedSec);
  const session = {
    id: uid(),
    startTs: t.startedAt,
    endTs: now,
    durationSec,
    plannedMin: Math.round(t.plannedSec / 60),
    intensity: t.intensity,
    pulseWidth: t.pulseWidth,
    frequency: t.frequency,
    endedBy: reason, // 'completed' | 'stopped' | 'emergency' | 'disconnected'
  };
  return {
    ...state,
    sessions: durationSec >= 1 ? [session, ...state.sessions] : state.sessions,
    therapy: {
      ...state.therapy, status: 'OFF', startedAt: null, plannedSec: 0,
      lastEnd: { reason, durationSec, at: now },
    },
  };
}

export function reducer(state, action) {
  switch (action.type) {
    case 'HYDRATE': {
      const p = action.payload || {};
      return {
        ...state,
        hydrated: true,
        profile: { ...state.profile, ...(p.profile || {}) },
        device: { ...state.device, ...(p.device || {}), connected: true },
        sensorRanges: { ...state.sensorRanges, ...(p.sensorRanges || {}) },
        therapySettings: { ...state.therapySettings, ...(p.therapySettings || {}) },
        reminders: { ...state.reminders, ...(p.reminders || {}) },
        painEntries: Array.isArray(p.painEntries) ? p.painEntries : [],
        sessions: Array.isArray(p.sessions) ? p.sessions : [],
        reportNotes: p.reportNotes || {},
        therapy: { ...state.therapy, intensity: (p.therapySettings || state.therapySettings).intensity },
      };
    }
    case 'SET_PROFILE':
      return { ...state, profile: { ...state.profile, ...action.patch } };
    case 'SET_DEVICE': {
      let next = { ...state, device: { ...state.device, ...action.patch } };
      if (action.patch.connected === false) next = finishSession(next, 'disconnected', action.now || Date.now());
      return next;
    }
    case 'SET_RANGES':
      return { ...state, sensorRanges: action.ranges };
    case 'SET_THERAPY_SETTINGS':
      return { ...state, therapySettings: { ...state.therapySettings, ...action.patch } };
    case 'SET_REMINDERS':
      return { ...state, reminders: { ...state.reminders, ...action.patch } };

    case 'ADD_PAIN': {
      const entry = {
        id: uid(),
        ts: action.ts || Date.now(),
        level: clamp(Math.round(action.level), 0, 10),
        note: (action.note || '').trim(),
      };
      return { ...state, painEntries: [entry, ...state.painEntries].sort((a, b) => b.ts - a.ts) };
    }
    case 'UPDATE_PAIN':
      return {
        ...state,
        painEntries: state.painEntries.map((e) => (e.id === action.id ? { ...e, ...action.patch } : e)),
      };
    case 'DELETE_PAIN':
      return { ...state, painEntries: state.painEntries.filter((e) => e.id !== action.id) };
    case 'DELETE_SESSION':
      return { ...state, sessions: state.sessions.filter((s) => s.id !== action.id) };
    case 'SET_REPORT_NOTE': {
      const notes = { ...state.reportNotes };
      if (action.text.trim()) notes[action.key] = action.text.trim();
      else delete notes[action.key];
      return { ...state, reportNotes: notes };
    }

    case 'THERAPY_START': {
      if (state.therapy.status === 'ON' || !state.device.connected) return state;
      const s = state.therapySettings;
      return {
        ...state,
        therapy: {
          status: 'ON',
          startedAt: action.now,
          plannedSec: s.durationMin * 60,
          intensity: s.intensity,
          pulseWidth: s.pulseWidth,
          frequency: s.frequency,
          lastEnd: null,
        },
      };
    }
    case 'THERAPY_STOP':
      // reason: 'completed' | 'stopped' | 'emergency'
      return finishSession(state, action.reason || 'stopped', action.now);
    case 'THERAPY_SET_INTENSITY': {
      const v = clamp(Math.round(action.value), 1, 10);
      return {
        ...state,
        therapySettings: { ...state.therapySettings, intensity: v },
        therapy: state.therapy.status === 'ON' ? { ...state.therapy, intensity: v } : state.therapy,
      };
    }

    case 'ADD_SAMPLE':
      return {
        ...state,
        painEntries: [...action.pain, ...state.painEntries].sort((a, b) => b.ts - a.ts),
        sessions: [...action.sessions, ...state.sessions].sort((a, b) => b.startTs - a.startTs),
      };
    case 'RESET_ALL':
      return { ...initialState, hydrated: true };
    default:
      return state;
  }
}
