import { addDays, startOfDay, uid } from '../utils/format';

// Optional demo records (Profile > Load sample data). They are random, flagged
// `sample: true`, and are ordinary saved records afterwards (they appear in
// History and Reports). The pain trend drifts down so the graphs have a story.
export function generateSample(now = Date.now(), days = 14) {
  const today = startOfDay(now);
  const pain = [];
  const sessions = [];
  for (let i = days - 1; i >= 0; i--) {
    const day = addDays(today, -i);
    const base = 7 - ((days - 1 - i) / (days - 1)) * 4; // 7 -> 3
    const morning = day + (8 + Math.floor(Math.random() * 2)) * 3600e3 + Math.floor(Math.random() * 50) * 60e3;
    if (morning < now) {
      pain.push({
        id: uid(), sample: true, note: '', ts: morning,
        level: Math.max(0, Math.min(10, Math.round(base + (Math.random() * 2 - 1)))),
      });
    }
    const evening = day + (18 + Math.floor(Math.random() * 3)) * 3600e3;
    if (evening < now && Math.random() > 0.35) {
      const dur = [10, 15, 20, 20, 30][Math.floor(Math.random() * 5)];
      sessions.push({
        id: uid(), sample: true, startTs: evening, endTs: evening + dur * 60e3,
        durationSec: dur * 60, plannedMin: dur,
        intensity: 3 + Math.floor(Math.random() * 5), pulseWidth: 200, frequency: 50,
        endedBy: 'completed',
      });
    }
  }
  return { pain, sessions };
}
