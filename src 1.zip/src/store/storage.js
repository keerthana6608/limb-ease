import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'limbease/state/v1';

export async function loadPersisted() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    console.warn('LimbEase: could not load saved data', e);
    return null;
  }
}

export async function savePersisted(data) {
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(data));
  } catch (e) {
    console.warn('LimbEase: could not save data', e);
  }
}

export async function clearPersisted() {
  try {
    await AsyncStorage.removeItem(KEY);
  } catch (e) {
    console.warn('LimbEase: could not clear data', e);
  }
}
