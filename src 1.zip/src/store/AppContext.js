import React, {
  createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef,
} from 'react';
import { initialState, reducer, toPersisted } from './reducer';
import { clearPersisted, loadPersisted, savePersisted } from './storage';
import { generateSample } from './sampleData';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const stateRef = useRef(state);
  stateRef.current = state;

  // 1) Load saved data once at startup.
  useEffect(() => {
    let alive = true;
    loadPersisted().then((data) => {
      if (alive) dispatch({ type: 'HYDRATE', payload: data });
    });
    return () => { alive = false; };
  }, []);

  // 2) Save whenever persisted data changes (after hydration only).
  useEffect(() => {
    if (!state.hydrated) return undefined;
    const t = setTimeout(() => savePersisted(toPersisted(state)), 300);
    return () => clearTimeout(t);
  }, [
    state.hydrated, state.profile, state.device.name, state.device.mode, state.sensorRanges,
    state.therapySettings, state.reminders, state.painEntries, state.sessions, state.reportNotes,
  ]); // eslint-disable-line react-hooks/exhaustive-deps

  // 3) Global therapy timer: ends the session automatically when time is up.
  const therapyOn = state.therapy.status === 'ON';
  useEffect(() => {
    if (!therapyOn) return undefined;
    const id = setInterval(() => {
      const t = stateRef.current.therapy;
      if (t.status === 'ON' && Date.now() - t.startedAt >= t.plannedSec * 1000) {
        dispatch({ type: 'THERAPY_STOP', reason: 'completed', now: t.startedAt + t.plannedSec * 1000 });
      }
    }, 500);
    return () => clearInterval(id);
  }, [therapyOn]);

  const actions = useMemo(() => ({
    setProfile: (patch) => dispatch({ type: 'SET_PROFILE', patch }),
    setDevice: (patch) => dispatch({ type: 'SET_DEVICE', patch, now: Date.now() }),
    setRanges: (ranges) => dispatch({ type: 'SET_RANGES', ranges }),
    setTherapySettings: (patch) => dispatch({ type: 'SET_THERAPY_SETTINGS', patch }),
    setReminders: (patch) => dispatch({ type: 'SET_REMINDERS', patch }),
    addPain: (level, note) => dispatch({ type: 'ADD_PAIN', level, note }),
    updatePain: (id, patch) => dispatch({ type: 'UPDATE_PAIN', id, patch }),
    deletePain: (id) => dispatch({ type: 'DELETE_PAIN', id }),
    deleteSession: (id) => dispatch({ type: 'DELETE_SESSION', id }),
    setReportNote: (key, text) => dispatch({ type: 'SET_REPORT_NOTE', key, text }),
    startTherapy: () => dispatch({ type: 'THERAPY_START', now: Date.now() }),
    stopTherapy: () => dispatch({ type: 'THERAPY_STOP', reason: 'stopped', now: Date.now() }),
    emergencyStop: () => dispatch({ type: 'THERAPY_STOP', reason: 'emergency', now: Date.now() }),
    setIntensity: (value) => dispatch({ type: 'THERAPY_SET_INTENSITY', value }),
    loadSample: () => {
      const { pain, sessions } = generateSample();
      dispatch({ type: 'ADD_SAMPLE', pain, sessions });
    },
    resetAll: async () => {
      dispatch({ type: 'THERAPY_STOP', reason: 'stopped', now: Date.now() });
      await clearPersisted();
      dispatch({ type: 'RESET_ALL' });
    },
  }), []);

  const value = useMemo(() => ({ state, ...actions }), [state, actions]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside <AppProvider>');
  return ctx;
}

// Elapsed seconds of the running session (re-renders once per second while ON).
export function useElapsed() {
  const { state } = useApp();
  const { status, startedAt, plannedSec } = state.therapy;
  const [, force] = React.useReducer((x) => x + 1, 0);
  useEffect(() => {
    if (status !== 'ON') return undefined;
    const id = setInterval(force, 1000);
    return () => clearInterval(id);
  }, [status]);
  if (status !== 'ON') return { elapsedSec: 0, plannedSec: 0, remainingSec: 0 };
  const elapsedSec = Math.min(plannedSec, Math.max(0, Math.floor((Date.now() - startedAt) / 1000)));
  return { elapsedSec, plannedSec, remainingSec: plannedSec - elapsedSec };
}
