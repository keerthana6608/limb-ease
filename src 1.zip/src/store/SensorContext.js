import React, {
  createContext, useCallback, useContext, useEffect, useMemo, useRef, useState,
} from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { useApp } from './AppContext';
import { createSensorSource } from '../sensors';
import { HISTORY_POINTS } from '../config/demo';

const SensorContext = createContext(null);

export function SensorProvider({ children }) {
  const { state } = useApp();
  const [reading, setReading] = useState(null);
  const [history, setHistory] = useState([]);
  const [error, setError] = useState(null);
  const sourceRef = useRef(null);
  const rangesRef = useRef(state.sensorRanges);
  rangesRef.current = state.sensorRanges;
  const modeRef = useRef(state.device.mode);
  modeRef.current = state.device.mode;
  const [isSimulated, setIsSimulated] = useState(true);

  const stop = useCallback(() => {
    if (sourceRef.current) sourceRef.current.stop();
    sourceRef.current = null;
  }, []);

  const start = useCallback(() => {
    if (sourceRef.current) return;
    const src = createSensorSource({ mode: modeRef.current, getRanges: () => rangesRef.current });
    sourceRef.current = src;
    setIsSimulated(src.isSimulated);
    setError(null);
    src.start(
      (r) => {
        setReading(r);
        setHistory((h) => [...h.slice(-(HISTORY_POINTS - 1)), r]);
      },
      (e) => setError(e.message || String(e)),
    );
  }, []);

  useEffect(() => stop, [stop]);

  const clearHistory = useCallback(() => { setHistory([]); setReading(null); }, []);

  const value = useMemo(
    () => ({ reading, history, error, isSimulated, start, stop, clearHistory }),
    [reading, history, error, isSimulated, start, stop, clearHistory],
  );
  return <SensorContext.Provider value={value}>{children}</SensorContext.Provider>;
}

export function useSensors() {
  const ctx = useContext(SensorContext);
  if (!ctx) throw new Error('useSensors must be used inside <SensorProvider>');
  return ctx;
}

// Streams only while the calling screen is focused AND the device is connected.
export function useSensorStream() {
  const sensors = useSensors();
  const { state } = useApp();
  const connected = state.device.connected;
  const { start, stop } = sensors;
  useFocusEffect(
    useCallback(() => {
      if (connected) start();
      return () => stop();
    }, [connected, start, stop]),
  );
  return sensors;
}
