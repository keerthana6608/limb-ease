// Demo configuration. NONE of these numbers are medical thresholds.
// They only exist so the simulated app has something to show.

export const DEFAULT_SENSOR_RANGES = {
  pressure: { min: 30, max: 70 }, // kPa  - simulator output range
  flex: { min: 10, max: 120 },    // deg  - simulator output range
  temp: { min: 30, max: 35 },     // degC - simulator output range
};

// Fixed scales used to draw the gauges.
export const GAUGE_SCALE = {
  pressure: { min: 0, max: 100, unit: 'kPa', label: 'Pressure' },
  flex: { min: 0, max: 180, unit: '°', label: 'Flex Angle' },
  temp: { min: 20, max: 50, unit: '°C', label: 'Temperature' },
};

// "Normal" band used by the Knee Condition card (demo only).
export const DEMO_NORMAL_BAND = {
  pressure: { min: 10, max: 85 },
  flex: { min: 0, max: 150 },
  temp: { min: 28, max: 37.5 },
};

export const SIM_INTERVAL_MS = 1000;
export const HISTORY_POINTS = 60;

export const PULSE_WIDTH_OPTIONS = [50, 100, 150, 200, 250, 300, 350, 400]; // µs
export const FREQUENCY_OPTIONS = [1, 2, 5, 10, 20, 50, 80, 100, 120];        // Hz
export const DURATION_OPTIONS = [1, 5, 10, 15, 20, 30, 45, 60];              // min
