import React from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Card, Header, ListRow, Screen } from '../components/ui';
import { useApp } from '../store/AppContext';
import { colors } from '../theme';

export default function ProfileScreen({ navigation }) {
  const { state, loadSample, resetAll } = useApp();
  const { profile, reminders } = state;

  const confirmReset = (title, msg) => {
    Alert.alert(title, msg, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Erase everything',
        style: 'destructive',
        onPress: async () => {
          await resetAll();
          navigation.navigate('Tabs', { screen: 'Home' });
        },
      },
    ]);
  };

  return (
    <Screen tabbed>
      <Header title="Profile" onBack={() => navigation.navigate('Home')} />

      <View style={styles.userRow}>
        <View style={styles.avatar}><Ionicons name="person" size={30} color="#fff" /></View>
        <View style={{ flex: 1, marginLeft: 14 }}>
          <Text style={styles.name}>{profile.name || 'User'}</Text>
          <Text style={styles.email}>{profile.email}</Text>
        </View>
        <Pressable onPress={() => navigation.navigate('PersonalInfo')} hitSlop={10} accessibilityLabel="Edit profile">
          <Ionicons name="pencil" size={20} color={colors.text} />
        </Pressable>
      </View>

      <Card style={{ padding: 0, overflow: 'hidden' }}>
        <ListRow label="Personal Information" onPress={() => navigation.navigate('PersonalInfo')} />
        <ListRow label="Device Information" onPress={() => navigation.navigate('DeviceInfo')} />
        <ListRow label="Therapy Settings" onPress={() => navigation.navigate('TherapySettings')} />
        <ListRow
          label="Reminders"
          value={reminders.enabled ? 'ON' : 'OFF'}
          valueColor={reminders.enabled ? colors.green : colors.muted}
          onPress={() => navigation.navigate('Reminders')}
          last
        />
      </Card>

      <Card style={{ padding: 0, overflow: 'hidden' }}>
        <ListRow label="Pain Tracking" icon="bar-chart-outline" onPress={() => navigation.navigate('PainTracking')} />
        <ListRow label="Reports" icon="document-text-outline" onPress={() => navigation.navigate('Reports')} />
        <ListRow label="Emergency Stop" icon="alert-circle-outline" danger onPress={() => navigation.navigate('Emergency')} last />
      </Card>

      <Card style={{ padding: 0, overflow: 'hidden' }}>
        <ListRow label="About Limb Ease" onPress={() => navigation.navigate('About')} />
        <ListRow
          label="Load sample data"
          onPress={() => Alert.alert('Add sample data?', 'Adds about two weeks of random demo pain records and therapy sessions so the graphs and reports have something to show. You can delete them any time.', [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Add', onPress: () => { loadSample(); Alert.alert('Done', 'Sample records added. Check History, Pain Tracking and Reports.'); } },
          ])}
        />
        <ListRow
          label="Reset all data"
          danger
          onPress={() => confirmReset('Reset all data?', 'Deletes every pain record, session, note and setting stored on this device.')}
        />
        <ListRow
          label="Logout"
          danger
          rightIcon="log-out-outline"
          onPress={() => confirmReset('Logout (demo)?', 'There is no account in this prototype. Logging out clears the local profile and all saved data, like a fresh install.')}
          last
        />
      </Card>
      <Text style={styles.ver}>Limb Ease v1.0.0 · student prototype · demo mode</Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  userRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, paddingHorizontal: 2 },
  avatar: { width: 56, height: 56, borderRadius: 28, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' },
  name: { fontSize: 18, fontWeight: '700', color: colors.text },
  email: { fontSize: 13, color: colors.muted, marginTop: 2 },
  ver: { textAlign: 'center', color: colors.faint, fontSize: 11, marginTop: 4 },
});
