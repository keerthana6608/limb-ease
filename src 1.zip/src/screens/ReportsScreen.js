import React, { useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card, Header, Screen, Segmented, StatRow } from '../components/ui';
import { useApp } from '../store/AppContext';
import { colors } from '../theme';
import { formatDuration } from '../utils/format';
import { periodRange, shiftAnchor, summarizePeriod } from '../utils/stats';
import { exportReportPdf } from '../utils/report';

export default function ReportsScreen({ navigation }) {
  const { state, setReportNote } = useApp();
  const [filter, setFilter] = useState('Daily');
  const [anchor, setAnchor] = useState(Date.now());
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);

  const summary = useMemo(
    () => summarizePeriod(filter, anchor, state.painEntries, state.sessions),
    [filter, anchor, state.painEntries, state.sessions],
  );
  const noteKey = summary.range.key;
  const note = state.reportNotes[noteKey] || '';
  useEffect(() => { setEditing(false); }, [noteKey]);

  const isCurrent = periodRange(filter, Date.now()).key === noteKey;
  const reliefColor = { good: colors.green, bad: colors.red, muted: colors.muted }[summary.relief.tone];

  const download = async () => {
    setBusy(true);
    try {
      const res = await exportReportPdf({ filter, summary, note, profile: state.profile });
      if (res.kind === 'saved') Alert.alert('Report created', `PDF saved to:\n${res.uri}`);
    } catch (e) {
      Alert.alert('Could not create PDF', String(e && e.message ? e.message : e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <Header title="Reports" onBack={() => navigation.goBack()} />
      <Segmented
        options={['Daily', 'Weekly', 'Monthly']}
        value={filter}
        onChange={(f) => { setFilter(f); setAnchor(Date.now()); }}
      />

      <Card style={styles.dateCard}>
        <Pressable onPress={() => setAnchor(shiftAnchor(filter, anchor, -1))} hitSlop={10} accessibilityLabel="Previous period">
          <Ionicons name="chevron-back" size={20} color={colors.text} />
        </Pressable>
        <Text style={styles.dateText}>{summary.range.label}</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
          <Pressable onPress={() => setAnchor(Date.now())} hitSlop={10} accessibilityLabel="Jump to today">
            <Ionicons name="calendar-outline" size={20} color={colors.muted} />
          </Pressable>
          <Pressable
            onPress={() => !isCurrent && setAnchor(shiftAnchor(filter, anchor, 1))}
            hitSlop={10}
            accessibilityLabel="Next period"
            style={isCurrent && { opacity: 0.25 }}
          >
            <Ionicons name="chevron-forward" size={20} color={colors.text} />
          </Pressable>
        </View>
      </Card>

      <Card style={{ padding: 0 }}>
        <StatRow label="Average Pain Level" value={summary.avgPain == null ? 'No data' : `${summary.avgPain} /10`} />
        <StatRow label="Therapy Duration" value={formatDuration(summary.totalSec)} />
        <StatRow label="Sessions" value={String(summary.sessionCount)} />
        <StatRow label="Pain Relief Achieved" value={summary.relief.label} valueColor={reliefColor} />
        <StatRow label="Pain Records" value={String(summary.pain.length)} last />
      </Card>

      <Card>
        <View style={styles.noteHead}>
          <Text style={styles.noteTitle}>Notes</Text>
          {!editing ? (
            <Pressable onPress={() => { setDraft(note); setEditing(true); }} hitSlop={10}>
              <Text style={styles.link}>{note ? 'Edit' : 'Add note'}</Text>
            </Pressable>
          ) : null}
        </View>
        {editing ? (
          <>
            <TextInput
              value={draft}
              onChangeText={setDraft}
              multiline
              autoFocus
              placeholder="Write a note for this period"
              placeholderTextColor={colors.faint}
              style={styles.noteInput}
            />
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Button title="CANCEL" variant="outline" style={{ flex: 1, height: 44 }} onPress={() => setEditing(false)} />
              <Button
                title="SAVE NOTE"
                style={{ flex: 1, height: 44 }}
                onPress={() => { setReportNote(noteKey, draft); setEditing(false); }}
              />
            </View>
          </>
        ) : (
          <Text style={{ color: note ? colors.text : colors.muted }}>{note || 'No notes added'}</Text>
        )}
      </Card>

      <Button title={busy ? 'CREATING PDF…' : 'DOWNLOAD REPORT'} icon="download-outline" onPress={download} disabled={busy} />
      <Text style={styles.foot}>
        The PDF is built from the records saved on this device. Therapy and sensor data in this prototype are simulated.
      </Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  dateCard: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12 },
  dateText: { fontSize: 15, fontWeight: '600', color: colors.text, flex: 1, textAlign: 'center' },
  noteHead: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  noteTitle: { fontSize: 14, fontWeight: '700', color: colors.text },
  link: { color: colors.blue, fontWeight: '600' },
  noteInput: {
    borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 10, minHeight: 80,
    textAlignVertical: 'top', color: colors.text, marginBottom: 10,
  },
  foot: { fontSize: 11, color: colors.muted, textAlign: 'center', marginTop: 10 },
});
