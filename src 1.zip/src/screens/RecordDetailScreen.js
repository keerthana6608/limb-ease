import React, { useEffect, useState } from 'react';
import { Alert, StyleSheet, Text, TextInput, View } from 'react-native';
import { Button, Card, Header, Screen, StatRow } from '../components/ui';
import { useApp } from '../store/AppContext';
import { colors } from '../theme';
import { formatDateTime, formatDuration } from '../utils/format';
import { painLabel } from '../utils/stats';

const END_TEXT = {
  completed: 'Completed',
  stopped: 'Stopped by user',
  emergency: 'Emergency stop',
  disconnected: 'Device disconnected',
};

export default function RecordDetailScreen({ navigation, route }) {
  const { kind, id } = route.params;
  const { state, updatePain, deletePain, deleteSession } = useApp();
  const pain = kind === 'pain' ? state.painEntries.find((p) => p.id === id) : null;
  const session = kind === 'session' ? state.sessions.find((s) => s.id === id) : null;
  const [note, setNote] = useState(pain ? pain.note : '');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!pain && !session) navigation.goBack(); // record was deleted
  }, [pain, session]); // eslint-disable-line react-hooks/exhaustive-deps

  const confirmDelete = () => {
    Alert.alert('Delete this record?', 'This cannot be undone. Reports and graphs will update.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => (pain ? deletePain(id) : deleteSession(id)) },
    ]);
  };

  return (
    <Screen>
      <Header title={pain ? 'Pain Record' : 'Therapy Session'} onBack={() => navigation.goBack()} />
      {pain ? (
        <>
          <Card style={{ alignItems: 'center', paddingVertical: 22 }}>
            <Text style={styles.big}>{pain.level}<Text style={styles.small}> /10</Text></Text>
            <Text style={styles.label}>{painLabel(pain.level)}</Text>
            <Text style={styles.when}>{formatDateTime(pain.ts)}</Text>
            {pain.sample ? <Text style={styles.sample}>Sample data</Text> : null}
          </Card>
          <Card>
            <Text style={styles.title}>Note</Text>
            <TextInput
              value={note}
              onChangeText={(t) => { setNote(t); setSaved(false); }}
              placeholder="No note"
              placeholderTextColor={colors.faint}
              multiline
              style={styles.input}
            />
            <Button
              title={saved ? 'SAVED' : 'SAVE NOTE'}
              variant="outline"
              style={{ height: 44 }}
              onPress={() => { updatePain(id, { note: note.trim() }); setSaved(true); }}
            />
          </Card>
        </>
      ) : null}

      {session ? (
        <Card style={{ padding: 0 }}>
          <StatRow label="Started" value={formatDateTime(session.startTs)} />
          <StatRow label="Ended" value={formatDateTime(session.endTs)} />
          <StatRow label="Duration" value={formatDuration(session.durationSec)} />
          <StatRow label="Planned" value={`${session.plannedMin} min`} />
          <StatRow label="Intensity" value={`${session.intensity}/10`} />
          <StatRow label="Pulse width" value={`${session.pulseWidth} µs`} />
          <StatRow label="Frequency" value={`${session.frequency} Hz`} />
          <StatRow
            label="Ended by"
            value={END_TEXT[session.endedBy] || '—'}
            valueColor={session.endedBy === 'emergency' ? colors.red : undefined}
            last={!session.sample}
          />
          {session.sample ? <StatRow label="Source" value="Sample data" last /> : null}
        </Card>
      ) : null}

      <View style={{ marginTop: 6 }}>
        <Button title="DELETE RECORD" variant="soft" icon="trash-outline" onPress={confirmDelete} />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  big: { fontSize: 48, fontWeight: '800', color: colors.text },
  small: { fontSize: 18, fontWeight: '500', color: colors.muted },
  label: { fontSize: 16, fontWeight: '600', color: colors.text, marginTop: 2 },
  when: { marginTop: 8, color: colors.muted },
  sample: { marginTop: 6, fontSize: 11, color: colors.amber, fontWeight: '700' },
  title: { fontSize: 14, fontWeight: '700', marginBottom: 8, color: colors.text },
  input: {
    borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 10, minHeight: 70,
    textAlignVertical: 'top', color: colors.text, marginBottom: 10,
  },
});
