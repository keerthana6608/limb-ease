import React, { useState } from 'react';
import { Alert, Pressable, StyleSheet, Switch, Text, View } from 'react-native';
import Slider from '@react-native-community/slider';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card, Header, ListRow, Screen } from '../components/ui';
import SheetModal from '../components/SheetModal';
import { useApp, useElapsed } from '../store/AppContext';
import { DURATION_OPTIONS, FREQUENCY_OPTIONS, PULSE_WIDTH_OPTIONS } from '../config/demo';
import { colors } from '../theme';
import { formatClock, formatDuration } from '../utils/format';

const END_TEXT = {
  completed: 'Completed',
  stopped: 'Stopped by user',
  emergency: 'Emergency stop',
  disconnected: 'Stopped (device disconnected)',
};

export default function TherapyScreen({ navigation }) {
  const { state, setTherapySettings, setIntensity, startTherapy, stopTherapy } = useApp();
  const { elapsedSec, plannedSec, remainingSec } = useElapsed();
  const [picker, setPicker] = useState(null); // 'pulseWidth' | 'frequency' | 'durationMin'

  const on = state.therapy.status === 'ON';
  const connected = state.device.connected;
  const s = on
    ? { intensity: state.therapy.intensity, pulseWidth: state.therapy.pulseWidth, frequency: state.therapy.frequency, durationMin: Math.round(plannedSec / 60) }
    : state.therapySettings;
  const last = state.therapy.lastEnd;

  const requestStart = () => {
    if (!connected) {
      Alert.alert('Device not connected', 'Connect the (demo) device from the Home screen first.');
      return;
    }
    startTherapy();
  };

  const onToggle = (v) => (v ? requestStart() : stopTherapy());

  const pickers = {
    pulseWidth: { title: 'Pulse Width', options: PULSE_WIDTH_OPTIONS.map((v) => ({ label: `${v} µs`, value: v })) },
    frequency: { title: 'Frequency', options: FREQUENCY_OPTIONS.map((v) => ({ label: `${v} Hz`, value: v })) },
    durationMin: { title: 'Session Time', options: DURATION_OPTIONS.map((v) => ({ label: `${v} min`, value: v })) },
  };

  const statusText = on
    ? 'Running'
    : last
      ? `${END_TEXT[last.reason] || 'Stopped'} · ${formatDuration(last.durationSec)}`
      : 'Idle';
  const statusColor = on ? colors.green : last && last.reason === 'emergency' ? colors.red : colors.muted;

  return (
    <Screen tabbed>
      <Header title="Therapy Control" onBack={() => navigation.navigate('Home')} />

      <View style={styles.simNote}>
        <Ionicons name="information-circle-outline" size={16} color={colors.amber} />
        <Text style={styles.simNoteText}>Software simulation only. No real electrical stimulation is produced.</Text>
      </View>

      <Card>
        <View style={styles.rowBetween}>
          <View style={{ flex: 1 }}>
            <Text style={styles.cardTitle}>TENS Therapy</Text>
            <Text style={styles.muted}>
              Status: <Text style={{ color: statusColor, fontWeight: '700' }}>{statusText}</Text>
            </Text>
          </View>
          <Switch
            value={on}
            onValueChange={onToggle}
            trackColor={{ false: '#D4D4D4', true: colors.black }}
            thumbColor="#fff"
          />
        </View>
      </Card>

      {on ? (
        <Card>
          <Text style={styles.cardTitle}>Session in progress</Text>
          <Text style={styles.clock}>{formatClock(elapsedSec)}</Text>
          <View style={styles.progressTrack}>
            <View style={[styles.progressFill, { width: `${plannedSec ? (elapsedSec / plannedSec) * 100 : 0}%` }]} />
          </View>
          <View style={styles.rowBetween}>
            <Text style={styles.muted}>Elapsed</Text>
            <Text style={styles.muted}>Remaining {formatClock(remainingSec)}</Text>
          </View>
        </Card>
      ) : null}

      <Card>
        <View style={styles.rowBetween}>
          <Text style={styles.cardTitle}>Intensity Level</Text>
          <Text style={styles.big}>{s.intensity}<Text style={styles.small}> /10</Text></Text>
        </View>
        <View style={styles.sliderRow}>
          <Pressable style={styles.stepBtn} onPress={() => setIntensity(s.intensity - 1)} accessibilityLabel="Decrease intensity">
            <Ionicons name="remove" size={18} color={colors.text} />
          </Pressable>
          <Slider
            style={{ flex: 1, height: 40 }}
            minimumValue={1}
            maximumValue={10}
            step={1}
            value={s.intensity}
            onValueChange={(v) => setIntensity(v)}
            minimumTrackTintColor={colors.black}
            maximumTrackTintColor="#D8D8D8"
            thumbTintColor={colors.black}
          />
          <Pressable style={styles.stepBtn} onPress={() => setIntensity(s.intensity + 1)} accessibilityLabel="Increase intensity">
            <Ionicons name="add" size={18} color={colors.text} />
          </Pressable>
        </View>
      </Card>

      <Card style={{ padding: 0, overflow: 'hidden' }}>
        <ListRow label="Pulse Width" value={`${s.pulseWidth} µs`} onPress={on ? undefined : () => setPicker('pulseWidth')} />
        <ListRow label="Frequency" value={`${s.frequency} Hz`} onPress={on ? undefined : () => setPicker('frequency')} />
        <ListRow label="Session Time" value={`${s.durationMin} min`} onPress={on ? undefined : () => setPicker('durationMin')} last />
      </Card>
      {on ? <Text style={[styles.muted, { marginBottom: 10, marginTop: -4 }]}>Pulse width, frequency and session time are locked while therapy is running.</Text> : null}

      {on ? (
        <Button title="STOP THERAPY" variant="red" icon="stop-circle" onPress={stopTherapy} />
      ) : (
        <Button title="START THERAPY" onPress={requestStart} icon="play" />
      )}

      <Pressable onPress={() => navigation.navigate('Emergency')} style={styles.emergencyLink} accessibilityRole="button">
        <Ionicons name="alert-circle" size={16} color={colors.red} />
        <Text style={styles.emergencyText}>Emergency Stop</Text>
      </Pressable>

      {picker ? (
        <SheetModal
          visible
          title={pickers[picker].title}
          options={pickers[picker].options}
          selected={state.therapySettings[picker]}
          onSelect={(v) => setTherapySettings({ [picker]: v })}
          onClose={() => setPicker(null)}
        />
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  simNote: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.amberSoft, borderRadius: 10, padding: 10, marginBottom: 12 },
  simNoteText: { flex: 1, marginLeft: 8, fontSize: 12, color: '#7A5600' },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  cardTitle: { fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 4 },
  muted: { fontSize: 13, color: colors.muted },
  big: { fontSize: 22, fontWeight: '700', color: colors.text },
  small: { fontSize: 13, fontWeight: '500', color: colors.muted },
  sliderRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  stepBtn: { width: 30, height: 30, borderRadius: 15, borderWidth: 1.5, borderColor: colors.borderStrong, alignItems: 'center', justifyContent: 'center' },
  clock: { fontSize: 36, fontWeight: '800', color: colors.text, fontVariant: ['tabular-nums'], marginVertical: 4 },
  progressTrack: { height: 8, borderRadius: 4, backgroundColor: '#E8E8E8', overflow: 'hidden', marginVertical: 8 },
  progressFill: { height: 8, backgroundColor: colors.green },
  emergencyLink: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 16, padding: 8 },
  emergencyText: { marginLeft: 6, color: colors.red, fontWeight: '700' },
});
