// Sub-screens opened from Profile: Personal Info, Device Info, Therapy Settings, Reminders, About.
import React, { useState } from 'react';
import { Alert, Pressable, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card, Header, ListRow, Screen, Segmented, SimBadge, StatRow } from '../components/ui';
import SheetModal from '../components/SheetModal';
import { useApp } from '../store/AppContext';
import {
  DEFAULT_SENSOR_RANGES, DURATION_OPTIONS, FREQUENCY_OPTIONS, GAUGE_SCALE, PULSE_WIDTH_OPTIONS,
} from '../config/demo';
import { colors } from '../theme';

function Field({ label, value, onChangeText, keyboardType, placeholder, multiline, style }) {
  return (
    <View style={[{ marginBottom: 12 }, style]}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        keyboardType={keyboardType}
        placeholder={placeholder}
        placeholderTextColor={colors.faint}
        multiline={multiline}
        style={[styles.input, multiline && { height: 80, textAlignVertical: 'top', paddingTop: 10 }]}
        autoCapitalize={keyboardType ? 'none' : 'sentences'}
      />
    </View>
  );
}

export function PersonalInfoScreen({ navigation }) {
  const { state, setProfile } = useApp();
  const [p, setP] = useState(state.profile);
  const set = (k) => (v) => setP((x) => ({ ...x, [k]: v }));

  const save = () => {
    const age = p.age === '' ? '' : String(parseInt(p.age, 10));
    if (p.age !== '' && (Number.isNaN(+age) || +age < 1 || +age > 120)) {
      Alert.alert('Check age', 'Enter an age between 1 and 120.');
      return;
    }
    setProfile({ ...p, name: p.name.trim() || 'User', age });
    navigation.goBack();
  };

  return (
    <Screen>
      <Header title="Personal Information" onBack={() => navigation.goBack()} />
      <Card>
        <Field label="Name" value={p.name} onChangeText={set('name')} />
        <Field label="Email" value={p.email} onChangeText={set('email')} keyboardType="email-address" />
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Field label="Age" value={p.age} onChangeText={set('age')} keyboardType="number-pad" style={{ flex: 1 }} />
          <Field label="Gender" value={p.gender} onChangeText={set('gender')} style={{ flex: 1 }} />
        </View>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Field label="Height (cm)" value={p.heightCm} onChangeText={set('heightCm')} keyboardType="decimal-pad" style={{ flex: 1 }} />
          <Field label="Weight (kg)" value={p.weightKg} onChangeText={set('weightKg')} keyboardType="decimal-pad" style={{ flex: 1 }} />
        </View>
        <Text style={styles.fieldLabel}>Affected knee</Text>
        <Segmented options={['Left', 'Right', 'Both']} value={p.kneeSide} onChange={set('kneeSide')} />
        <Field label="Condition / notes" value={p.condition} onChangeText={set('condition')} multiline placeholder="e.g. mild arthritis, post-injury recovery" />
      </Card>
      <Button title="SAVE" onPress={save} />
    </Screen>
  );
}

const RANGE_KEYS = ['pressure', 'flex', 'temp'];

export function DeviceInfoScreen({ navigation }) {
  const { state, setDevice, setRanges } = useApp();
  const { device } = state;
  const [r, setR] = useState(() => {
    const o = {};
    RANGE_KEYS.forEach((k) => { o[k] = { min: String(state.sensorRanges[k].min), max: String(state.sensorRanges[k].max) }; });
    return o;
  });

  const saveRanges = () => {
    const out = {};
    for (const k of RANGE_KEYS) {
      const min = parseFloat(r[k].min);
      const max = parseFloat(r[k].max);
      const sc = GAUGE_SCALE[k];
      if (Number.isNaN(min) || Number.isNaN(max) || min >= max || min < sc.min || max > sc.max) {
        Alert.alert('Check ' + sc.label, `Enter numbers with min < max, between ${sc.min} and ${sc.max} ${sc.unit}.`);
        return;
      }
      out[k] = { min, max };
    }
    setRanges(out);
    Alert.alert('Saved', 'The simulator now generates readings inside these ranges.');
  };

  const resetRanges = () => {
    const o = {};
    RANGE_KEYS.forEach((k) => { o[k] = { min: String(DEFAULT_SENSOR_RANGES[k].min), max: String(DEFAULT_SENSOR_RANGES[k].max) }; });
    setR(o);
    setRanges(DEFAULT_SENSOR_RANGES);
  };

  const setField = (k, f) => (v) => setR((x) => ({ ...x, [k]: { ...x[k], [f]: v } }));

  return (
    <Screen>
      <Header title="Device Information" onBack={() => navigation.goBack()} />
      <Card style={{ padding: 0 }}>
        <StatRow label="Device" value={device.name} />
        <StatRow label="Model" value={device.model} />
        <StatRow label="Firmware" value={device.firmware} />
        <StatRow label="Data source" value="Simulated" />
        <StatRow label="Connection" value={device.connected ? 'Connected (demo)' : 'Disconnected'} valueColor={device.connected ? colors.green : colors.muted} last />
      </Card>

      <Card>
        <View style={styles.switchRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.sectionTitle}>Demo device connected</Text>
            <Text style={styles.hint}>Turning this off stops any running therapy and the live readings.</Text>
          </View>
          <Switch
            value={device.connected}
            onValueChange={(v) => setDevice({ connected: v })}
            trackColor={{ false: '#D4D4D4', true: colors.black }}
            thumbColor="#fff"
          />
        </View>
      </Card>

      <Card>
        <SimBadge text="SIMULATOR SETTINGS" />
        <Text style={[styles.hint, { marginTop: 8, marginBottom: 10 }]}>
          Choose the range the simulator generates for each sensor. These are demo values, not medical limits.
        </Text>
        {RANGE_KEYS.map((k) => (
          <View key={k} style={{ marginBottom: 4 }}>
            <Text style={styles.fieldLabel}>{GAUGE_SCALE[k].label} ({GAUGE_SCALE[k].unit})</Text>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Field label="Min" value={r[k].min} onChangeText={setField(k, 'min')} keyboardType="decimal-pad" style={{ flex: 1 }} />
              <Field label="Max" value={r[k].max} onChangeText={setField(k, 'max')} keyboardType="decimal-pad" style={{ flex: 1 }} />
            </View>
          </View>
        ))}
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Button title="RESET" variant="outline" style={{ flex: 1, height: 46 }} onPress={resetRanges} />
          <Button title="SAVE RANGES" style={{ flex: 1.4, height: 46 }} onPress={saveRanges} />
        </View>
      </Card>

      <Card>
        <Text style={styles.sectionTitle}>Real hardware (future)</Text>
        <Text style={styles.hint}>
          Arduino Uno + pressure, flex and temperature sensors + Bluetooth module. Not connected yet — see
          src/sensors/BluetoothSensorSource.js for where to plug it in.
        </Text>
      </Card>
    </Screen>
  );
}

export function TherapySettingsScreen({ navigation }) {
  const { state, setTherapySettings } = useApp();
  const s = state.therapySettings;
  const [picker, setPicker] = useState(null);
  const pickers = {
    pulseWidth: { title: 'Pulse Width', options: PULSE_WIDTH_OPTIONS.map((v) => ({ label: `${v} µs`, value: v })) },
    frequency: { title: 'Frequency', options: FREQUENCY_OPTIONS.map((v) => ({ label: `${v} Hz`, value: v })) },
    durationMin: { title: 'Session Time', options: DURATION_OPTIONS.map((v) => ({ label: `${v} min`, value: v })) },
  };
  const running = state.therapy.status === 'ON';
  return (
    <Screen>
      <Header title="Therapy Settings" onBack={() => navigation.goBack()} />
      <Text style={[styles.hint, { marginBottom: 10 }]}>
        Default values used the next time you start a session. {running ? 'A session is running now; changes apply to the next one.' : ''}
      </Text>
      <Card style={{ padding: 0, overflow: 'hidden' }}>
        <View style={styles.stepRow}>
          <Text style={styles.listLabel}>Intensity</Text>
          <View style={styles.stepper}>
            <Pressable style={styles.stepBtn} onPress={() => setTherapySettings({ intensity: Math.max(1, s.intensity - 1) })}>
              <Ionicons name="remove" size={18} color={colors.text} />
            </Pressable>
            <Text style={styles.stepVal}>{s.intensity}/10</Text>
            <Pressable style={styles.stepBtn} onPress={() => setTherapySettings({ intensity: Math.min(10, s.intensity + 1) })}>
              <Ionicons name="add" size={18} color={colors.text} />
            </Pressable>
          </View>
        </View>
        <ListRow label="Pulse Width" value={`${s.pulseWidth} µs`} onPress={() => setPicker('pulseWidth')} />
        <ListRow label="Frequency" value={`${s.frequency} Hz`} onPress={() => setPicker('frequency')} />
        <ListRow label="Session Time" value={`${s.durationMin} min`} onPress={() => setPicker('durationMin')} last />
      </Card>
      {picker ? (
        <SheetModal
          visible
          title={pickers[picker].title}
          options={pickers[picker].options}
          selected={s[picker]}
          onSelect={(v) => setTherapySettings({ [picker]: v })}
          onClose={() => setPicker(null)}
        />
      ) : null}
    </Screen>
  );
}

export function RemindersScreen({ navigation }) {
  const { state, setReminders } = useApp();
  const [time, setTime] = useState(state.reminders.time);
  const valid = /^([01]\d|2[0-3]):[0-5]\d$/.test(time);
  return (
    <Screen>
      <Header title="Reminders" onBack={() => navigation.goBack()} />
      <Card>
        <View style={styles.switchRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.sectionTitle}>Daily therapy reminder</Text>
            <Text style={styles.hint}>
              When the app is open after this time and no session has been logged today, a reminder appears on the Home screen.
            </Text>
          </View>
          <Switch
            value={state.reminders.enabled}
            onValueChange={(v) => setReminders({ enabled: v })}
            trackColor={{ false: '#D4D4D4', true: colors.black }}
            thumbColor="#fff"
          />
        </View>
      </Card>
      <Card>
        <Field label="Reminder time (24-hour HH:MM)" value={time} onChangeText={setTime} keyboardType="numbers-and-punctuation" placeholder="09:00" />
        {!valid ? <Text style={{ color: colors.red, marginBottom: 8 }}>Use the format HH:MM, for example 18:30.</Text> : null}
        <Button
          title="SAVE TIME"
          disabled={!valid}
          onPress={() => { setReminders({ time }); navigation.goBack(); }}
        />
      </Card>
      <Text style={styles.hint}>Phone notifications while the app is closed are not part of this prototype.</Text>
    </Screen>
  );
}

export function AboutScreen({ navigation }) {
  return (
    <Screen>
      <Header title="About Limb Ease" onBack={() => navigation.goBack()} />
      <Card style={{ alignItems: 'center', paddingVertical: 22 }}>
        <View style={styles.logo}><Ionicons name="pulse" size={34} color="#fff" /></View>
        <Text style={styles.appName}>Limb Ease</Text>
        <Text style={styles.hint}>Smart Wearable Knee Pain Relief System · v1.0.0</Text>
      </Card>
      <Card>
        <Text style={styles.sectionTitle}>What this is</Text>
        <Text style={styles.body}>
          A college-project prototype companion app for a smart knee brace. It monitors pressure, knee flex angle and
          temperature, controls a TENS-style therapy session, tracks pain and builds reports.
        </Text>
      </Card>
      <Card>
        <Text style={styles.sectionTitle}>Important</Text>
        <Text style={styles.body}>
          • Sensor readings are simulated; no hardware is connected yet.{'\n'}
          • Therapy control is a software simulation and produces no electrical stimulation.{'\n'}
          • Normal ranges shown are demo values, not medical thresholds.{'\n'}
          • This app is not a medical device and does not diagnose or treat any condition. Speak to a qualified clinician about knee pain.{'\n'}
          • All data stays on this phone (no account, no cloud).
        </Text>
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  fieldLabel: { fontSize: 12, fontWeight: '600', color: colors.muted, marginBottom: 6 },
  input: {
    borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingHorizontal: 12,
    height: 46, color: colors.text, backgroundColor: '#fff',
  },
  switchRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  sectionTitle: { fontSize: 15, fontWeight: '700', color: colors.text, marginBottom: 4 },
  hint: { fontSize: 12, color: colors.muted, lineHeight: 17 },
  body: { fontSize: 14, color: colors.text, lineHeight: 21 },
  stepRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 52,
    paddingHorizontal: 14, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border,
  },
  listLabel: { fontSize: 15, color: colors.text, fontWeight: '500' },
  stepper: { flexDirection: 'row', alignItems: 'center' },
  stepBtn: { width: 30, height: 30, borderRadius: 15, borderWidth: 1.5, borderColor: colors.borderStrong, alignItems: 'center', justifyContent: 'center' },
  stepVal: { width: 56, textAlign: 'center', fontWeight: '700', color: colors.text },
  logo: { width: 64, height: 64, borderRadius: 16, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  appName: { fontSize: 22, fontWeight: '800', color: colors.text, marginBottom: 4 },
});
