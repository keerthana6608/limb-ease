import React, { useState } from 'react';
import { StyleSheet, Text, Vibration, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Button, Header, Screen } from '../components/ui';
import Siren from '../components/Siren';
import { useApp } from '../store/AppContext';
import { colors } from '../theme';

export default function EmergencyScreen({ navigation }) {
  const { state, emergencyStop } = useApp();
  const [done, setDone] = useState(false);
  const wasRunning = state.therapy.status === 'ON';

  const stopNow = () => {
    emergencyStop();          // sets therapy OFF everywhere + records the session
    Vibration.vibrate(400);
    setDone(true);
  };

  return (
    <Screen scroll={false} contentStyle={{ justifyContent: 'space-between' }}>
      <Header title="Emergency" onBack={() => navigation.goBack()} />

      <View style={styles.center}>
        {done ? (
          <>
            <View style={styles.okCircle}><Ionicons name="checkmark" size={64} color="#fff" /></View>
            <Text style={[styles.heading, { color: colors.green }]}>THERAPY STOPPED</Text>
            <Text style={styles.text}>
              {wasRunning
                ? 'The simulated session was ended immediately and saved to History as an emergency stop. Therapy is now OFF.'
                : 'Therapy was already OFF. All simulated stimulation is confirmed OFF.'}
            </Text>
          </>
        ) : (
          <>
            <Siren />
            <Text style={styles.heading}>EMERGENCY STOP</Text>
            <Text style={styles.text}>
              This will immediately stop the therapy and all electrical stimulation.
            </Text>
            <Text style={styles.status}>
              Current status: <Text style={{ fontWeight: '800', color: wasRunning ? colors.green : colors.muted }}>
                {wasRunning ? 'THERAPY ON' : 'THERAPY OFF'}
              </Text>
            </Text>
          </>
        )}
      </View>

      <View style={{ paddingBottom: 16 }}>
        {done ? (
          <Button title="BACK TO HOME" onPress={() => navigation.navigate('Tabs', { screen: 'Home' })} />
        ) : (
          <>
            <Button title="STOP THERAPY NOW" variant="red" onPress={stopNow} style={{ height: 56, marginBottom: 12 }} />
            <Button title="CANCEL" variant="outline" onPress={() => navigation.goBack()} style={{ height: 56 }} />
          </>
        )}
        <Text style={styles.sim}>Prototype: this stops the software simulation only.</Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  center: { alignItems: 'center', paddingHorizontal: 12 },
  heading: { marginTop: 18, fontSize: 24, fontWeight: '800', color: colors.red, letterSpacing: 0.5 },
  text: { marginTop: 10, textAlign: 'center', fontSize: 15, color: colors.text, lineHeight: 22 },
  status: { marginTop: 14, color: colors.muted },
  okCircle: { width: 110, height: 110, borderRadius: 55, backgroundColor: colors.green, alignItems: 'center', justifyContent: 'center' },
  sim: { marginTop: 12, fontSize: 11, color: colors.faint, textAlign: 'center' },
});
