import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card, Empty, Header, Screen, Segmented } from '../components/ui';
import { useApp } from '../store/AppContext';
import { colors } from '../theme';
import { formatDate, formatDuration, formatTime } from '../utils/format';

function Item({ item, onPress }) {
  const isPain = item.kind === 'pain';
  return (
    <Card onPress={onPress} style={styles.item}>
      <View style={{ width: 104 }}>
        <Text style={styles.date}>{formatDate(item.ts)}</Text>
        <Text style={styles.time}>{formatTime(item.ts)}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.colLabel}>{isPain ? 'Pain Level' : 'Intensity'}</Text>
        <Text style={styles.colValue}>{isPain ? item.data.level : item.data.intensity}/10</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.colLabel}>{isPain ? 'Type' : 'Duration'}</Text>
        <Text style={styles.colValue}>{isPain ? 'Pain log' : formatDuration(item.data.durationSec)}</Text>
      </View>
      <Ionicons name="chevron-forward" size={16} color={colors.muted} />
    </Card>
  );
}

export default function HistoryScreen({ navigation }) {
  const { state } = useApp();
  const [filter, setFilter] = useState('All');

  const items = useMemo(() => {
    const pain = state.painEntries.map((p) => ({ kind: 'pain', id: p.id, ts: p.ts, data: p }));
    const sess = state.sessions.map((s) => ({ kind: 'session', id: s.id, ts: s.startTs, data: s }));
    const all = filter === 'Pain' ? pain : filter === 'Therapy' ? sess : [...pain, ...sess];
    return all.sort((a, b) => b.ts - a.ts);
  }, [state.painEntries, state.sessions, filter]);

  return (
    <Screen tabbed scroll={false}>
      <Header title="History" onBack={() => navigation.navigate('Home')} />
      <View style={styles.actions}>
        <Button title="Log pain" icon="add" style={styles.actionBtn} onPress={() => navigation.navigate('PainTracking')} />
        <Button title="Reports" icon="document-text-outline" variant="outline" style={styles.actionBtn} onPress={() => navigation.navigate('Reports')} />
      </View>
      <Segmented options={['All', 'Pain', 'Therapy']} value={filter} onChange={setFilter} />
      <FlatList
        data={items}
        keyExtractor={(it) => `${it.kind}-${it.id}`}
        renderItem={({ item }) => (
          <Item item={item} onPress={() => navigation.navigate('RecordDetail', { kind: item.kind, id: item.id })} />
        )}
        contentContainerStyle={{ paddingBottom: 24, flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={(
          <Empty
            icon="time-outline"
            title="No records yet"
            hint="Save a pain level or run a therapy session and it will show up here automatically."
          />
        )}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  actions: { flexDirection: 'row', gap: 10, marginBottom: 12 },
  actionBtn: { flex: 1, height: 44 },
  item: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12 },
  date: { fontSize: 13, fontWeight: '600', color: colors.text },
  time: { fontSize: 12, color: colors.muted, marginTop: 2 },
  colLabel: { fontSize: 11, color: colors.muted },
  colValue: { fontSize: 14, fontWeight: '700', color: colors.text, marginTop: 2 },
});
