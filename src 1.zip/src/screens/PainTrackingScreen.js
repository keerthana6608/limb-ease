import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import Slider from '@react-native-community/slider';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card, Header, Screen } from '../components/ui';
import LineChart from '../components/LineChart';
import SheetModal from '../components/SheetModal';
import { useApp } from '../store/AppContext';
import { colors } from '../theme';
import { average, between, dailyAverages, improvement, painLabel } from '../utils/stats';
import { addDays, round1, startOfDay } from '../utils/format';

function PainBar({ value, onChange }) {
  const [w, setW] = useState(0);
  return (
    <View style={{ height: 44, justifyContent: 'center' }} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      {w > 0 ? (
        <Svg width={w} height={10} style={{ position: 'absolute', left: 0, top: 17 }}>
          <Defs>
            <LinearGradient id="pain" x1="0" y1="0" x2="1" y2="0">
              <Stop offset="0" stopColor="#2BB673" />
              <Stop offset="0.5" stopColor="#F5C842" />
              <Stop offset="1" stopColor="#E5322D" />
            </LinearGradient>
          </Defs>
          <Rect x="0" y="0" width={w} height="10" rx="5" fill="url(#pain)" />
        </Svg>
      ) : null}
      <Slider
        style={{ width: '100%', height: 44 }}
        minimumValue={0}
        maximumValue={10}
        step={1}
        value={value}
        onValueChange={onChange}
        minimumTrackTintColor="transparent"
        maximumTrackTintColor="transparent"
        thumbTintColor={colors.black}
        accessibilityLabel="Pain level slider"
      />
    </View>
  );
}

export default function PainTrackingScreen({ navigation }) {
  const { state, addPain } = useApp();
  const [level, setLevel] = useState(state.painEntries[0] ? state.painEntries[0].level : 3);
  const [note, setNote] = useState('');
  const [days, setDays] = useState(7);
  const [picker, setPicker] = useState(false);
  const [saved, setSaved] = useState(false);
  const timer = useRef(null);
  useEffect(() => () => clearTimeout(timer.current), []);

  const now = Date.now();
  const entries = state.painEntries;
  const series = useMemo(() => dailyAverages(entries, now, days), [entries, days]); // eslint-disable-line react-hooks/exhaustive-deps
  const inWindow = between(entries, addDays(startOfDay(now), -(days - 1)), addDays(startOfDay(now), 1));
  const avg = average(inWindow.map((e) => e.level));
  const imp = improvement(entries, now);

  const step = Math.ceil(days / 7);
  const xLabels = series
    .map((d, i) => ({ index: i, text: d.label }))
    .filter((l) => (series.length - 1 - l.index) % step === 0);

  const save = () => {
    addPain(level, note);
    setNote('');
    setSaved(true);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setSaved(false), 2500);
  };

  return (
    <Screen>
      <Header title="Pain Tracking" onBack={() => navigation.goBack()} />

      <Card>
        <Text style={styles.cardTitle}>Current Pain Level</Text>
        <View style={styles.rowBetween}>
          <Text style={styles.big}>{level}<Text style={styles.small}> /10</Text></Text>
          <Text style={styles.label}>{painLabel(level)}</Text>
        </View>
        <PainBar value={level} onChange={setLevel} />
        <View style={styles.rowBetween}>
          <Text style={styles.scale}>0{'\n'}No Pain</Text>
          <Text style={[styles.scale, { textAlign: 'right' }]}>10{'\n'}Worst Pain</Text>
        </View>
        <TextInput
          value={note}
          onChangeText={setNote}
          placeholder="Optional note (e.g. after walking)"
          placeholderTextColor={colors.faint}
          style={styles.input}
          maxLength={200}
        />
        <Button title="SAVE PAIN LEVEL" onPress={save} icon="save-outline" />
        {saved ? (
          <View style={styles.savedRow}>
            <Ionicons name="checkmark-circle" size={18} color={colors.green} />
            <Text style={styles.savedText}>Saved — it now appears in History.</Text>
          </View>
        ) : null}
      </Card>

      <Card>
        <View style={styles.rowBetween}>
          <Text style={styles.cardTitle}>Pain History</Text>
          <Pressable onPress={() => setPicker(true)} style={styles.dropdown}>
            <Text style={styles.dropText}>{days} Days</Text>
            <Ionicons name="chevron-down" size={14} color={colors.text} />
          </Pressable>
        </View>
        {inWindow.length === 0 ? (
          <Text style={styles.empty}>No pain records in this period yet. Save one above to see your graph.</Text>
        ) : null}
        <LineChart
          height={190}
          yMin={0}
          yMax={10}
          yTicks={[0, 2, 4, 6, 8, 10]}
          dots
          pointLabels={days <= 14}
          xLabels={xLabels}
          series={[{ color: colors.black, data: series.map((d) => d.avg) }]}
        />
        <Text style={styles.footnote}>Daily average of your saved records. Days without records are left blank.</Text>
      </Card>

      <View style={styles.rowGap}>
        <Card style={{ flex: 1 }}>
          <Text style={styles.statTitle}>Average Pain</Text>
          <Text style={styles.stat}>
            {avg == null ? '—' : round1(avg)}
            {avg == null ? null : <Text style={styles.small}> /10</Text>}
          </Text>
          <Text style={styles.footnote}>{inWindow.length} record{inWindow.length === 1 ? '' : 's'} · last {days} days</Text>
        </Card>
        <Card style={{ flex: 1 }}>
          <Text style={styles.statTitle}>Improvement</Text>
          {imp.ok ? (
            <>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text style={[styles.stat, { color: imp.pct > 0 ? colors.green : imp.pct < 0 ? colors.red : colors.text }]}>
                  {Math.abs(imp.pct)}<Text style={styles.small}>%</Text>
                </Text>
                <Ionicons
                  name={imp.pct > 0 ? 'trending-down' : imp.pct < 0 ? 'trending-up' : 'remove'}
                  size={20}
                  color={imp.pct > 0 ? colors.green : imp.pct < 0 ? colors.red : colors.muted}
                  style={{ marginLeft: 6 }}
                />
              </View>
              <Text style={styles.footnote}>{imp.pct > 0 ? 'less pain' : imp.pct < 0 ? 'more pain' : 'no change'} vs last week</Text>
            </>
          ) : (
            <>
              <Text style={[styles.stat, { color: colors.faint }]}>—</Text>
              <Text style={styles.footnote}>{imp.reason}</Text>
            </>
          )}
        </Card>
      </View>

      <SheetModal
        visible={picker}
        title="Show history for"
        options={[7, 14, 30].map((d) => ({ label: `${d} Days`, value: d }))}
        selected={days}
        onSelect={setDays}
        onClose={() => setPicker(false)}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  rowGap: { flexDirection: 'row', gap: 12 },
  cardTitle: { fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 6 },
  big: { fontSize: 34, fontWeight: '800', color: colors.text },
  small: { fontSize: 14, fontWeight: '500', color: colors.muted },
  label: { fontSize: 14, fontWeight: '600', color: colors.text },
  scale: { fontSize: 11, color: colors.muted, marginBottom: 12 },
  input: {
    borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingHorizontal: 12,
    height: 44, color: colors.text, marginBottom: 12,
  },
  savedRow: { flexDirection: 'row', alignItems: 'center', marginTop: 10 },
  savedText: { marginLeft: 6, color: colors.green, fontWeight: '600' },
  dropdown: {
    flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderColor: colors.border,
    borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6,
  },
  dropText: { fontSize: 13, color: colors.text },
  empty: { fontSize: 12, color: colors.muted, marginBottom: 6 },
  footnote: { fontSize: 11, color: colors.muted, marginTop: 4 },
  statTitle: { fontSize: 12, fontWeight: '700', color: colors.text, marginBottom: 6 },
  stat: { fontSize: 28, fontWeight: '800', color: colors.text },
});
