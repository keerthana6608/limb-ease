import React, { useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Card, Screen } from '../components/ui';
import KneeBrace from '../components/KneeBrace';
import SheetModal from '../components/SheetModal';
import { useApp, useElapsed } from '../store/AppContext';
import { colors } from '../theme';
import { formatClock, startOfDay } from '../utils/format';
import { painShort } from '../utils/stats';

export default function HomeScreen({ navigation }) {
  const { state, setDevice, startTherapy, stopTherapy } = useApp();
  const { elapsedSec, plannedSec } = useElapsed();
  const [menu, setMenu] = useState(false);
  const [reminderDismissed, setReminderDismissed] = useState(false);

  const on = state.therapy.status === 'ON';
  const connected = state.device.connected;
  const lastPain = state.painEntries[0];

  // In-app reminder banner (no OS notifications needed).
  const [hh, mm] = (state.reminders.time || '09:00').split(':').map((x) => parseInt(x, 10));
  const reminderAt = startOfDay(Date.now()) + ((hh || 0) * 60 + (mm || 0)) * 60000;
  const sessionToday = state.sessions.some((s) => s.startTs >= startOfDay(Date.now()));
  const showReminder = state.reminders.enabled && !reminderDismissed && !on && !sessionToday && Date.now() >= reminderAt;

  const toggleConnection = () => {
    if (connected && on) {
      Alert.alert('Disconnect device?', 'Therapy is running. Disconnecting will stop the session.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Disconnect', style: 'destructive', onPress: () => setDevice({ connected: false }) },
      ]);
      return;
    }
    setDevice({ connected: !connected });
  };

  const onPower = () => {
    if (on) { stopTherapy(); return; }
    if (!connected) {
      Alert.alert('Device not connected', 'Connect the (demo) device first using the Bluetooth button.');
      return;
    }
    const s = state.therapySettings;
    Alert.alert(
      'Start therapy?',
      `Simulated session: intensity ${s.intensity}/10, ${s.durationMin} min.\n(No real stimulation is produced.)`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Start', onPress: startTherapy },
      ],
    );
  };

  const menuItems = [
    { label: 'Pain Tracking', value: 'PainTracking', icon: 'bar-chart-outline' },
    { label: 'Reports', value: 'Reports', icon: 'document-text-outline' },
    { label: 'Device Information', value: 'DeviceInfo', icon: 'hardware-chip-outline' },
    { label: 'About Limb Ease', value: 'About', icon: 'information-circle-outline' },
    { label: 'Emergency Stop', value: 'Emergency', icon: 'alert-circle-outline', danger: true },
  ];

  return (
    <Screen tabbed>
      <View style={styles.topBar}>
        <Pressable onPress={() => setMenu(true)} hitSlop={10} accessibilityLabel="Open menu" style={styles.topBtn}>
          <Ionicons name="menu" size={28} color={colors.text} />
        </Pressable>
        <Pressable
          onPress={toggleConnection}
          accessibilityLabel="Toggle demo device connection"
          style={[styles.btCircle, !connected && { backgroundColor: '#8A8A8A' }]}
        >
          <Ionicons name={connected ? 'bluetooth' : 'bluetooth-outline'} size={18} color="#fff" />
        </Pressable>
      </View>

      <View style={{ alignItems: 'center' }}>
        <Text style={styles.brand}>LIMB EASE</Text>
        <Text style={styles.title}>Knee Pain</Text>
        <Text style={styles.title}>Relief System</Text>
        <View style={styles.statusRow}>
          <Ionicons name="bluetooth" size={13} color={connected ? colors.green : colors.faint} />
          <Text style={[styles.statusText, !connected && { color: colors.muted }]}>
            {connected ? 'Connected' : 'Disconnected'}
          </Text>
          <View style={styles.demoChip}><Text style={styles.demoChipText}>DEMO DEVICE</Text></View>
        </View>
      </View>

      <View style={{ alignItems: 'center', marginVertical: 6 }}>
        <KneeBrace connected={connected} active={on} />
      </View>

      {showReminder ? (
        <Card style={styles.reminder}>
          <Ionicons name="alarm-outline" size={20} color={colors.amber} />
          <Text style={{ flex: 1, marginLeft: 10, color: colors.text }}>
            Reminder ({state.reminders.time}): no therapy session logged today.
          </Text>
          <Pressable onPress={() => setReminderDismissed(true)} hitSlop={10}>
            <Ionicons name="close" size={20} color={colors.muted} />
          </Pressable>
        </Card>
      ) : null}

      <View style={styles.twoCol}>
        <Card style={styles.half}>
          <Text style={styles.cardTitle}>Therapy</Text>
          <View style={styles.rowBetween}>
            <Text style={[styles.bigStatus, on && { color: colors.green }]}>{on ? 'ON' : 'OFF'}</Text>
            <Pressable
              onPress={onPower}
              accessibilityLabel={on ? 'Stop therapy' : 'Start therapy'}
              style={[styles.powerBtn, on && { backgroundColor: colors.green, borderColor: colors.green }]}
            >
              <Ionicons name="power" size={24} color={on ? '#fff' : colors.text} />
            </Pressable>
          </View>
        </Card>

        <Card style={styles.half} onPress={() => navigation.navigate('PainTracking')}>
          <Text style={styles.cardTitle}>Pain Level</Text>
          <View style={styles.rowBetween}>
            <View>
              <Text style={styles.bigStatus}>
                {lastPain ? lastPain.level : '–'}
                <Text style={styles.small}> /10</Text>
              </Text>
              <Text style={styles.muted}>{lastPain ? painShort(lastPain.level) : 'Tap to log'}</Text>
            </View>
            <Ionicons name={lastPain && lastPain.level >= 7 ? 'sad-outline' : 'happy-outline'} size={28} color={colors.text} />
          </View>
        </Card>
      </View>

      <Card>
        <Text style={styles.cardTitle}>Session Time</Text>
        <View style={styles.rowBetween}>
          <View>
            <Text style={styles.clock}>{formatClock(elapsedSec)}</Text>
            {on ? <Text style={styles.muted}>of {formatClock(plannedSec)} · running</Text> : <Text style={styles.muted}>No active session</Text>}
          </View>
          <Ionicons name="time-outline" size={30} color={colors.muted} />
        </View>
      </Card>

      <Pressable onPress={() => navigation.navigate('Emergency')} style={styles.emergency} accessibilityRole="button">
        <Ionicons name="alert-circle" size={18} color={colors.red} />
        <Text style={styles.emergencyText}>EMERGENCY STOP</Text>
      </Pressable>

      <SheetModal
        visible={menu}
        title="Menu"
        options={menuItems}
        onSelect={(v) => navigation.navigate(v)}
        onClose={() => setMenu(false)}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', height: 52 },
  topBtn: { width: 40, height: 40, justifyContent: 'center' },
  btCircle: { width: 34, height: 34, borderRadius: 17, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' },
  brand: { fontSize: 11, letterSpacing: 3, color: colors.muted, fontWeight: '700', marginBottom: 4 },
  title: { fontSize: 28, fontWeight: '800', color: colors.text, lineHeight: 32 },
  statusRow: { flexDirection: 'row', alignItems: 'center', marginTop: 8 },
  statusText: { marginLeft: 5, color: colors.green, fontWeight: '600', fontSize: 14 },
  demoChip: { marginLeft: 8, backgroundColor: '#F0F0F0', borderRadius: 999, paddingHorizontal: 8, paddingVertical: 2 },
  demoChipText: { fontSize: 9, fontWeight: '700', color: colors.muted, letterSpacing: 0.5 },
  twoCol: { flexDirection: 'row', gap: 12 },
  half: { flex: 1 },
  cardTitle: { fontSize: 13, fontWeight: '700', color: colors.text, marginBottom: 10 },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  bigStatus: { fontSize: 26, fontWeight: '700', color: colors.text },
  small: { fontSize: 14, fontWeight: '500', color: colors.muted },
  muted: { fontSize: 12, color: colors.muted },
  powerBtn: {
    width: 44, height: 44, borderRadius: 22, borderWidth: 1.5, borderColor: colors.borderStrong,
    alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff',
  },
  clock: { fontSize: 30, fontWeight: '700', color: colors.text, fontVariant: ['tabular-nums'] },
  reminder: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.amberSoft, borderColor: '#F3DDA6' },
  emergency: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', height: 48, borderRadius: 12,
    borderWidth: 1.5, borderColor: colors.red, backgroundColor: colors.redSoft, marginTop: 4,
  },
  emergencyText: { marginLeft: 8, color: colors.red, fontWeight: '800', letterSpacing: 0.8 },
});
