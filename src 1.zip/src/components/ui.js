import React from 'react';
import {
  Pressable, ScrollView, StyleSheet, Text, View, ActivityIndicator,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius, shadow } from '../theme';

export function Screen({ children, scroll = true, tabbed = false, style, contentStyle }) {
  const insets = useSafeAreaInsets();
  const body = scroll ? (
    <ScrollView
      contentContainerStyle={[
        { paddingHorizontal: 16, paddingBottom: tabbed ? 24 : insets.bottom + 24 },
        contentStyle,
      ]}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
    >
      {children}
    </ScrollView>
  ) : (
    <View style={[{ flex: 1, paddingHorizontal: 16, paddingBottom: tabbed ? 0 : insets.bottom }, contentStyle]}>
      {children}
    </View>
  );
  return <View style={[{ flex: 1, backgroundColor: colors.bg, paddingTop: insets.top }, style]}>{body}</View>;
}

export function Header({ title, onBack, right }) {
  return (
    <View style={styles.header}>
      <View style={styles.headerSide}>
        {onBack ? (
          <Pressable onPress={onBack} hitSlop={12} accessibilityLabel="Go back" style={styles.iconBtn}>
            <Ionicons name="chevron-back" size={24} color={colors.text} />
          </Pressable>
        ) : null}
      </View>
      <Text style={styles.headerTitle} numberOfLines={1}>{title}</Text>
      <View style={[styles.headerSide, { alignItems: 'flex-end' }]}>{right}</View>
    </View>
  );
}

export function Card({ children, style, onPress }) {
  if (onPress) {
    return (
      <Pressable onPress={onPress} style={({ pressed }) => [styles.card, pressed && { opacity: 0.7 }, style]}>
        {children}
      </Pressable>
    );
  }
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Button({ title, onPress, variant = 'black', icon, disabled, style }) {
  const bg = { black: colors.black, red: colors.red, outline: '#fff', soft: colors.redSoft }[variant];
  const fg = { black: '#fff', red: '#fff', outline: colors.text, soft: colors.red }[variant];
  const border = variant === 'outline' ? colors.borderStrong : variant === 'soft' ? colors.red : 'transparent';
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: bg, borderColor: border },
        disabled && { opacity: 0.4 },
        pressed && { opacity: 0.8 },
        style,
      ]}
    >
      {icon ? <Ionicons name={icon} size={18} color={fg} style={{ marginRight: 8 }} /> : null}
      <Text style={[styles.buttonText, { color: fg }]}>{title}</Text>
    </Pressable>
  );
}

export function ListRow({ label, value, onPress, valueColor, danger, icon, last, rightIcon = 'chevron-forward' }) {
  const content = (
    <View style={[styles.listRow, !last && styles.listRowBorder]}>
      {icon ? <Ionicons name={icon} size={18} color={danger ? colors.red : colors.text} style={{ marginRight: 10 }} /> : null}
      <Text style={[styles.listLabel, danger && { color: colors.red }]}>{label}</Text>
      <View style={{ flex: 1 }} />
      {value != null ? (
        <Text style={[styles.listValue, valueColor && { color: valueColor }]}>{value}</Text>
      ) : null}
      {onPress && rightIcon ? (
        <Ionicons name={rightIcon} size={16} color={danger ? colors.red : colors.muted} style={{ marginLeft: 8 }} />
      ) : null}
    </View>
  );
  if (!onPress) return content;
  return <Pressable onPress={onPress} style={({ pressed }) => pressed && { backgroundColor: '#F5F5F5' }}>{content}</Pressable>;
}

export function StatRow({ label, value, valueColor, last }) {
  return (
    <View style={[styles.statRow, !last && styles.listRowBorder]}>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={[styles.statValue, valueColor && { color: valueColor }]}>{value}</Text>
    </View>
  );
}

export function SimBadge({ style, text = 'SIMULATED SENSOR DATA' }) {
  return (
    <View style={[styles.simBadge, style]}>
      <Ionicons name="flask-outline" size={14} color={colors.amber} />
      <Text style={styles.simText}>{text}</Text>
    </View>
  );
}

export function Segmented({ options, value, onChange }) {
  return (
    <View style={styles.segment}>
      {options.map((o) => {
        const active = o === value;
        return (
          <Pressable key={o} onPress={() => onChange(o)} style={[styles.segItem, active && styles.segActive]}>
            <Text style={[styles.segText, active && { color: '#fff' }]}>{o}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export function Loading() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg }}>
      <ActivityIndicator color={colors.black} />
    </View>
  );
}

export function Empty({ icon = 'file-tray-outline', title, hint, children }) {
  return (
    <View style={{ alignItems: 'center', padding: 28 }}>
      <Ionicons name={icon} size={40} color={colors.faint} />
      <Text style={{ marginTop: 10, fontSize: 16, fontWeight: '600', color: colors.text }}>{title}</Text>
      {hint ? <Text style={{ marginTop: 4, color: colors.muted, textAlign: 'center' }}>{hint}</Text> : null}
      <View style={{ marginTop: 14, alignSelf: 'stretch' }}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', height: 56, marginBottom: 6 },
  headerSide: { width: 56, justifyContent: 'center' },
  iconBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { flex: 1, textAlign: 'center', fontSize: 18, fontWeight: '600', color: colors.text },
  card: {
    backgroundColor: colors.card, borderRadius: radius.card, borderWidth: 1,
    borderColor: colors.border, padding: 14, marginBottom: 12, ...shadow,
  },
  button: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    height: 52, borderRadius: radius.button, borderWidth: 1.5, paddingHorizontal: 16,
  },
  buttonText: { fontSize: 15, fontWeight: '700', letterSpacing: 0.6 },
  listRow: { flexDirection: 'row', alignItems: 'center', minHeight: 48, paddingHorizontal: 14 },
  listRowBorder: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  listLabel: { fontSize: 15, color: colors.text, fontWeight: '500' },
  listValue: { fontSize: 15, color: colors.text, fontWeight: '600' },
  statRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 46, paddingHorizontal: 14 },
  statLabel: { fontSize: 15, color: colors.text },
  statValue: { fontSize: 15, fontWeight: '700', color: colors.text },
  simBadge: {
    flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start',
    backgroundColor: colors.amberSoft, borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 5,
  },
  simText: { marginLeft: 5, fontSize: 11, fontWeight: '700', color: colors.amber, letterSpacing: 0.4 },
  segment: {
    flexDirection: 'row', backgroundColor: '#EFEFEF', borderRadius: 10, padding: 3, marginBottom: 12,
  },
  segItem: { flex: 1, alignItems: 'center', paddingVertical: 8, borderRadius: 8 },
  segActive: { backgroundColor: colors.black },
  segText: { fontSize: 14, fontWeight: '600', color: colors.text },
});
