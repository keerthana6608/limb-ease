import React from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../theme';

/**
 * Bottom sheet used for both option pickers (with `selected`) and action menus.
 * options: [{ label, value, icon?, danger? }]
 */
export default function SheetModal({ visible, title, options, selected, onSelect, onClose }) {
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={styles.backdrop} onPress={onClose}>
        <Pressable style={[styles.sheet, { paddingBottom: insets.bottom + 12 }]} onPress={() => {}}>
          <View style={styles.grabber} />
          {title ? <Text style={styles.title}>{title}</Text> : null}
          <ScrollView style={{ maxHeight: 380 }}>
            {options.map((o) => {
              const isSel = selected !== undefined && o.value === selected;
              return (
                <Pressable
                  key={String(o.value)}
                  onPress={() => { onSelect(o.value); onClose(); }}
                  style={({ pressed }) => [styles.row, pressed && { backgroundColor: '#F4F4F4' }]}
                >
                  {o.icon ? (
                    <Ionicons name={o.icon} size={20} color={o.danger ? colors.red : colors.text} style={{ marginRight: 12 }} />
                  ) : null}
                  <Text style={[styles.label, o.danger && { color: colors.red }, isSel && { fontWeight: '700' }]}>
                    {o.label}
                  </Text>
                  <View style={{ flex: 1 }} />
                  {isSel ? <Ionicons name="checkmark" size={20} color={colors.black} /> : null}
                </Pressable>
              );
            })}
          </ScrollView>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, paddingTop: 8 },
  grabber: { alignSelf: 'center', width: 40, height: 4, borderRadius: 2, backgroundColor: '#D5D5D5', marginBottom: 8 },
  title: { textAlign: 'center', fontSize: 16, fontWeight: '700', marginBottom: 6, color: colors.text },
  row: { flexDirection: 'row', alignItems: 'center', minHeight: 52, paddingHorizontal: 20 },
  label: { fontSize: 16, color: colors.text },
});
