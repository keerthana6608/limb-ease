import React from 'react';
import Svg, { Line, Path, Rect } from 'react-native-svg';
import { colors } from '../theme';

export default function Siren({ size = 150, color = colors.red }) {
  const ray = { stroke: color, strokeWidth: 6, strokeLinecap: 'round' };
  return (
    <Svg width={size} height={size * 0.88} viewBox="0 0 150 132">
      <Line x1="75" y1="6" x2="75" y2="24" {...ray} />
      <Line x1="34" y1="22" x2="45" y2="35" {...ray} />
      <Line x1="116" y1="22" x2="105" y2="35" {...ray} />
      <Line x1="10" y1="62" x2="28" y2="66" {...ray} />
      <Line x1="140" y1="62" x2="122" y2="66" {...ray} />
      <Path d="M40 104 L40 74 Q40 42 75 42 Q110 42 110 74 L110 104 Z" fill={color} />
      <Rect x="52" y="60" width="8" height="30" rx="4" fill="#fff" opacity={0.35} />
      <Rect x="24" y="104" width="102" height="20" rx="6" fill="#111" />
    </Svg>
  );
}
