import React from 'react';
import Svg, { Circle, G, Path, Rect } from 'react-native-svg';

// Simple vector illustration of the smart knee brace (leg, black sleeve, hinge, sensor module).
export default function KneeBrace({ size = 190, connected = true, active = false }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 200 200">
      <G transform="rotate(-14 100 100)">
        {/* thigh + calf */}
        <Rect x="66" y="-6" width="68" height="84" rx="28" fill="#ECECEC" />
        <Rect x="70" y="124" width="60" height="84" rx="26" fill="#ECECEC" />
        {/* brace sleeve */}
        <Path d="M56 44 Q100 30 144 44 L150 150 Q100 166 50 150 Z" fill="#141414" />
        {/* straps */}
        <Rect x="50" y="56" width="100" height="13" rx="6" fill="#2D2D2D" />
        <Rect x="48" y="128" width="104" height="13" rx="6" fill="#2D2D2D" />
        {/* hinge bars */}
        <Rect x="146" y="62" width="9" height="76" rx="4.5" fill="#3B3B3B" />
        <Rect x="45" y="62" width="9" height="76" rx="4.5" fill="#3B3B3B" />
        {/* knee cap opening */}
        <Circle cx="100" cy="98" r="23" fill="#232323" stroke="#4A4A4A" strokeWidth="3" />
        <Circle cx="100" cy="98" r="9" fill="#5A5A5A" />
      </G>
      {/* sensor / stimulation module */}
      <Rect x="128" y="104" width="44" height="58" rx="11" fill="#262626" stroke="#555" strokeWidth="2" />
      <Circle cx="150" cy="120" r="4.5" fill={connected ? '#2ECC71' : '#8A8A8A'} />
      <Circle cx="150" cy="134" r="4.5" fill={active ? '#F5A524' : '#444'} />
      <Rect x="138" y="146" width="24" height="5" rx="2.5" fill="#444" />
    </Svg>
  );
}
