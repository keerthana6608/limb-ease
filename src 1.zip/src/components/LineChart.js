import React, { useState } from 'react';
import { View } from 'react-native';
import Svg, { Circle, Line, Path, Text as SvgText } from 'react-native-svg';
import { colors } from '../theme';

/**
 * Minimal SVG line chart (no chart library needed).
 *  series:  [{ color, data: (number|null)[] , width? }]   null = no value (gap)
 *  yMin/yMax/yTicks: vertical axis
 *  xLabels: [{ index, text }]
 *  dots / pointLabels: draw markers / numbers on real data points
 */
export default function LineChart({
  series, height = 190, yMin = 0, yMax = 10, yTicks = [0, 5, 10],
  xLabels = [], dots = false, pointLabels = false, anchorEnd = true,
}) {
  const [w, setW] = useState(0);
  const padL = 30;
  const padR = 12;
  const padT = 16;
  const padB = 24;
  const innerW = Math.max(0, w - padL - padR);
  const innerH = height - padT - padB;
  const n = Math.max(0, ...series.map((s) => s.data.length));

  const xAt = (i) => (n <= 1 ? padL + innerW / 2 : padL + (i / (n - 1)) * innerW);
  const yAt = (v) => padT + innerH - ((v - yMin) / (yMax - yMin)) * innerH;

  const pathFor = (data) => {
    let d = '';
    let started = false;
    data.forEach((v, i) => {
      if (v == null) return;
      d += `${started ? 'L' : 'M'} ${xAt(i).toFixed(1)} ${yAt(v).toFixed(1)} `;
      started = true;
    });
    return d.trim();
  };

  return (
    <View style={{ height }} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      {w > 0 ? (
        <Svg width={w} height={height}>
          {yTicks.map((t) => (
            <React.Fragment key={t}>
              <Line x1={padL} x2={w - padR} y1={yAt(t)} y2={yAt(t)} stroke="#EDEDED" strokeWidth={1} />
              <SvgText x={padL - 6} y={yAt(t) + 3.5} fontSize={10} fill={colors.muted} textAnchor="end">{String(t)}</SvgText>
            </React.Fragment>
          ))}
          {xLabels.map((l, k) => (
            <SvgText
              key={`${l.index}-${k}`}
              x={xAt(l.index)}
              y={height - 6}
              fontSize={10}
              fill={colors.muted}
              textAnchor={l.index === 0 && anchorEnd ? 'start' : l.index === n - 1 && anchorEnd ? 'end' : 'middle'}
            >
              {l.text}
            </SvgText>
          ))}
          {series.map((s, si) => (
            <Path
              key={`p${si}`}
              d={pathFor(s.data)}
              stroke={s.color}
              strokeWidth={s.width || 2}
              fill="none"
              strokeLinejoin="round"
              strokeLinecap="round"
            />
          ))}
          {dots
            ? series.map((s, si) =>
              s.data.map((v, i) =>
                v == null ? null : (
                  <React.Fragment key={`d${si}-${i}`}>
                    <Circle cx={xAt(i)} cy={yAt(v)} r={4} fill="#fff" stroke={s.color} strokeWidth={2} />
                    {pointLabels ? (
                      <SvgText x={xAt(i)} y={yAt(v) - 9} fontSize={11} fontWeight="600" fill={colors.text} textAnchor="middle">
                        {String(v)}
                      </SvgText>
                    ) : null}
                  </React.Fragment>
                ),
              ))
            : null}
        </Svg>
      ) : null}
    </View>
  );
}
