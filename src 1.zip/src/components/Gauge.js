import React from 'react';
import Svg, { Path } from 'react-native-svg';
import { colors } from '../theme';

const START = 150; // degrees (lower-left), sweeping clockwise 240deg to lower-right
const SWEEP = 240;

function polar(cx, cy, r, deg) {
  const a = (deg * Math.PI) / 180;
  return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) };
}

function arc(cx, cy, r, fromDeg, toDeg) {
  const s = polar(cx, cy, r, fromDeg);
  const e = polar(cx, cy, r, toDeg);
  const large = toDeg - fromDeg > 180 ? 1 : 0;
  return `M ${s.x.toFixed(2)} ${s.y.toFixed(2)} A ${r} ${r} 0 ${large} 1 ${e.x.toFixed(2)} ${e.y.toFixed(2)}`;
}

export default function Gauge({ value, min, max, color = colors.green, size = 78 }) {
  const stroke = 8;
  const r = (size - stroke) / 2;
  const c = size / 2;
  const f = value == null ? 0 : Math.min(1, Math.max(0, (value - min) / (max - min)));
  return (
    <Svg width={size} height={size * 0.82} viewBox={`0 0 ${size} ${size * 0.82}`}>
      <Path d={arc(c, c, r, START, START + SWEEP)} stroke={colors.track} strokeWidth={stroke} strokeLinecap="round" fill="none" />
      {f > 0.01 ? (
        <Path d={arc(c, c, r, START, START + SWEEP * f)} stroke={color} strokeWidth={stroke} strokeLinecap="round" fill="none" />
      ) : null}
    </Svg>
  );
}
